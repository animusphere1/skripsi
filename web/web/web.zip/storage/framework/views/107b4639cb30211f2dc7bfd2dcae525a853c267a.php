<script src="<?php echo e(asset('js/script.js')); ?>"></script>
<?php /**PATH D:\skripsiujungtanduk\web\web\resources\views/utils/mainjs.blade.php ENDPATH**/ ?>