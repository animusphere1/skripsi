<link rel="stylesheet" type="text/css"  href="<?php echo e(asset('css/styles.css')); ?>">
<?php /**PATH D:\skripsiujungtanduk\web\web\resources\views/utils/maincss.blade.php ENDPATH**/ ?>