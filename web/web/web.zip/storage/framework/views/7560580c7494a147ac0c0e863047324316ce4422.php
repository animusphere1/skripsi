<link rel="stylesheet" type="text/css"  href="<?php echo e(asset('css/main/main.css')); ?>">
<?php /**PATH D:\skripsiujungtanduk\web\web\resources\views/utils/css.blade.php ENDPATH**/ ?>