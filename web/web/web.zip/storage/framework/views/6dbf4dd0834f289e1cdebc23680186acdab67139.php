

<?php /**PATH D:\skripsiujungtanduk\web\web\resources\views/landing/content.blade.php ENDPATH**/ ?>