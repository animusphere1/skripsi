<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo $__env->make('utils.maincss', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Document</title>    

    <style>
        body h1{
            background-color: yellow;
            width: 20px;
            border-radius: 20px;
        }
    </style>
</head>
<body>
    <h1>
        text 1
    </h1>

    <?php echo $__env->make('utils.mainjs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('header'); ?>
</body>
</html><?php /**PATH D:\skripsiujungtanduk\web\web\resources\views/landing/base.blade.php ENDPATH**/ ?>