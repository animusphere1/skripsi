@extends('home.base')

@section('header')
    @include('home.header')
@endsection

@section('content')
    @include('home.content')
@endsection

{{-- @section('footer')
    @include('home.footer')
@endsection --}}