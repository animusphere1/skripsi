@extends('admin.base')

@section('header')
    @include('admin.header')
@endsection

@section('content')
    @include('admin.content')
@endsection