@extends('landing.base')

@section('header')
    @include('landing.header')
@endsection

@section('content')
    @include('landing.content')
@endsection