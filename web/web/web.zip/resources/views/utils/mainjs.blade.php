<script src="{{ asset('js/script.js') }}"></script>
